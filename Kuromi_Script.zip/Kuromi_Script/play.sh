
z="
";Cz='figl';Nz='lolc';Oz='at';Lz='Tube';Dz='et -';Iz=' lol';Kz='"You';Rz='y';Pz='node';Mz='" | ';Qz=' pla';Hz='y" |';Ez='f sm';Fz='all ';Az='clea';Gz='"Pla';Bz='r';Jz='cat';
eval "$Az$Bz$z$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$z$Cz$Dz$Ez$Fz$Kz$Lz$Mz$Nz$Oz$z$Pz$Qz$Rz"